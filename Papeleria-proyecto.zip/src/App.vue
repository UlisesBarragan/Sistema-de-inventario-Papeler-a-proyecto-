<template>
  <router-view /> <!-- Render the current route’s component -->
</template>

<script>
export default {
  name: "App",
};
</script>

<style>
/* Global styles if necessary */
</style>
