<template>
  <div class="consulta-inventario">
    <!-- Botón de regreso a la página principal -->
    <router-link to="/" class="back-button"> ← Página Principal </router-link>

    <h2>Consulta de Inventario</h2>

    <!-- Barra de búsqueda -->
    <input
      type="text"
      v-model="searchQuery"
      placeholder="Buscar producto..."
      class="search-bar"
    />

    <!-- Filtro por categoría -->
    <select v-model="selectedCategory" class="filter-select">
      <option value="">Todas las Categorías</option>
      <option v-for="categoria in uniqueCategories" :key="categoria" :value="categoria">
        {{ categoria }}
      </option>
    </select>

    <!-- Resumen de inventario -->
    <div class="resumen-inventario">
      <p>Total de productos: {{ totalProductos }}</p>
      <p>Con pocas unidades: {{ pocasUnidades }}</p>
      <p>Agotados: {{ agotados }}</p>
    </div>

    <!-- Condición para mostrar la tabla o el mensaje de "no resultados" -->
    <div v-if="filteredProductos.length > 0">
      <!-- Tabla de productos -->
      <table class="inventario-table">
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Categoría</th>
            <th>Cantidad</th>
            <th>Precio</th>
            <th>Estado</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="producto in filteredProductos" :key="producto.id">
            <td>{{ producto.nombre }}</td>
            <td>{{ producto.categoria }}</td>
            <td>{{ producto.cantidad }}</td>
            <td>{{ formatCurrency(producto.precio) }}</td>
            <td>{{ obtenerEstadoProducto(producto.cantidad) }}</td>
          </tr>
        </tbody>
      </table>
    </div>
    
    <!-- Mensaje cuando no hay resultados -->
    <p v-else class="no-results-message">
      No se encontraron productos que coincidan con la búsqueda.
    </p>
  </div>
</template>

<script>
export default {
  name: "ConsultarInventario",
  data() {
    return {
      searchQuery: "",
      selectedCategory: "",
      productos: [], // Inicialmente vacío, se cargará desde el JSON
    };
  },
  computed: {
    filteredProductos() {
      return this.productos.filter((producto) => {
        const normalizeText = (text) => 
          text.normalize("NFD").replace(/[\u0300-\u036f]/g, ""); // Normalizar acentos
        
        const matchesSearch = normalizeText(producto.nombre.toLowerCase()).includes(normalizeText(this.searchQuery.toLowerCase()));
        const matchesCategory = !this.selectedCategory || producto.categoria === this.selectedCategory;
        
        return matchesSearch && matchesCategory;
      });
    },
    uniqueCategories() {
      return [...new Set(this.productos.map((producto) => producto.categoria))];
    },
    totalProductos() {
      return this.productos.length;
    },
    pocasUnidades() {
      return this.productos.filter((producto) => producto.cantidad < 10 && producto.cantidad > 0).length;
    },
    agotados() {
      return this.productos.filter((producto) => producto.cantidad === 0).length;
    }
  },
  methods: {
    obtenerEstadoProducto(cantidad) {
      if (cantidad === 0) return "Agotado";
      if (cantidad < 10) return "Pocas unidades";
      return "Suficiente";
    },
    formatCurrency(value) {
      return `$${value.toFixed(2)}`;
    },
    cargarProductos() {
      fetch("/data/productos.json")
        .then((response) => {
          if (!response.ok) throw new Error("Error al cargar el archivo JSON");
          return response.json();
        })
        .then((data) => {
          this.productos = data;
        })
        .catch((error) => {
          console.error("Error:", error);
        });
    }
  },
  mounted() {
    this.cargarProductos(); 
  }
};
</script>

<style scoped>
/* Estilo general con un fondo de color sólido uniforme */
.consulta-inventario {
  min-height: 100vh;
  background-color: #36454f;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 40px 20px;
  color: #ecf0f1;
  border-radius: 15px;
  box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.2);
}

/* Título */
h2 {
  font-size: 2.2rem;
  margin-bottom: 20px;
  font-weight: 600;
  color: #ecf0f1;
}

/* Barra de búsqueda */
.search-bar {
  width: 100%;
  max-width: 500px;
  padding: 12px;
  margin-bottom: 15px;
  border: none;
  border-radius: 8px;
  font-size: 1rem;
  background-color: #ecf0f1;
  color: #333;
  box-shadow: inset 0px 2px 4px rgba(0, 0, 0, 0.1);
}

/* Selector de filtro */
.filter-select {
  width: 100%;
  max-width: 500px;
  padding: 12px;
  margin-bottom: 30px;
  border: none;
  border-radius: 8px;
  font-size: 1rem;
  background-color: #ecf0f1;
  color: #333;
  box-shadow: inset 0px 2px 4px rgba(0, 0, 0, 0.1);
}

/* Resumen de inventario */
.resumen-inventario {
  display: flex;
  justify-content: space-around;
  width: 100%;
  max-width: 500px;
  margin-top: 20px;
  padding: 15px;
  background-color: #34495e;
  border-radius: 8px;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.15);
}

.resumen-inventario p {
  margin: 0;
  font-size: 1.1rem;
  font-weight: 500;
}

/* Tabla de inventario */
.inventario-table {
  width: 100%;
  max-width: 800px;
  border-collapse: collapse;
  margin-top: 25px;
  background-color: #34495e;
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.15);
}

.inventario-table th,
.inventario-table td {
  padding: 15px;
  border: 1px solid #485460;
}

.inventario-table th {
  background-color: #3b3f45;
  color: #ecf0f1;
  font-weight: bold;
}

.inventario-table td {
  background-color: #2c3e50;
  text-align: center;
  color: #ecf0f1;
}

/* Efecto de hover para las filas de la tabla */
.inventario-table tr:hover td {
  background-color: #3b4a59;
}

/* Ajustes en los textos */
h2, .resumen-inventario p, .inventario-table th, .inventario-table td {
  transition: color 0.2s;
}

.no-results-message {
  margin-top: 20px;
  font-size: 1.2rem;
  color: #ecf0f1;
  background-color: #3b3f45;
  padding: 15px;
  border-radius: 8px;
  text-align: center;
  width: 100%;
  max-width: 500px;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.15);
}

.back-button {
  position: absolute;
  top: 20px;
  left: 20px;
  padding: 10px 20px;
  font-size: 1rem;
  font-weight: 500;
  color: #ecf0f1;
  background-color: #3b3f45;
  border-radius: 8px;
  text-decoration: none;
  transition: background-color 0.3s;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.15);
}

.back-button:hover {
  background-color: #485460;
}


</style>
