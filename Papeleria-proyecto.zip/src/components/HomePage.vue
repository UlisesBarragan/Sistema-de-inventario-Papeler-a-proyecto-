<template>
    <div id="home">
      <!-- Título de la papelería alineado a la izquierda -->
      <header>
        <h1>Papelería Lapicito</h1>
      </header>
  
      <!-- Opciones principales de navegación en el centro -->
      <div class="options">
        <router-link to="/consultar-inventario" class="option option-inventario">
          <span class="icon">📋</span>
          <p>Consultar Inventario</p>
        </router-link>
        <router-link to="/registrar-producto" class="option option-producto">
          <span class="icon">✏️</span>
          <p>Registrar Producto</p>
        </router-link>
      </div>
  
      <!-- Icono de perfil en la esquina superior derecha -->
      <div class="profile-icon">👤</div>
    </div>
  </template>
  
  <script>
  export default {
    name: "HomePage",
  };
  </script>
  
  <style scoped>
  /* Fuente personalizada */
  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap');
  
  #home {
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg, #2c3e50, #4b6584); /* Degradado sobrio */
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 20px;
    position: relative;
    color: #333;
  }
  
  /* Encabezado con título alineado a la izquierda */
  header {
    position: absolute;
    top: 20px;
    left: 20px;
  }
  
  h1 {
    color: #ecf0f1; /* Blanco suave */
    font-size: 1.8rem;
    margin: 0;
    text-align: left;
  }
  
  /* Contenedor de las opciones */
  .options {
    display: flex;
    gap: 20px;
    margin-top: 100px; /* Separación del título */
  }
  
  /* Estilo de las tarjetas */
  .option {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 380px;
    height: 280px;
    color: #fff;
    border-radius: 15px;
    text-decoration: none;
    box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.2);
    transition: transform 0.3s, box-shadow 0.3s;
    font-weight: 600;
  }
  
  .option:hover {
    transform: translateY(-5px);
    box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.3);
  }
  
  /* Colores más sobrios para las tarjetas */
  .option-inventario {
    background-color: #36454f; /* Gris azulado oscuro */
  }
  
  .option-producto {
    background-color: #7f8c8d; /* Gris oscuro */
  }
  
  /* Iconos más grandes */
  .icon {
    font-size: 3rem;
    margin-bottom: 10px;
  }
  
  /* Icono de perfil */
  .profile-icon {
    position: absolute;
    top: 20px;
    right: 20px;
    font-size: 2rem;
    color: #ecf0f1; /* Blanco suave */
    cursor: pointer;
  }
  </style>
  