import { createRouter, createWebHistory } from 'vue-router';
import HomePage from '@/components/HomePage.vue';
import ConsultarInventario from '@/components/ConsultarInventario.vue';


const routes = [
  { path: '/', component: HomePage }, // Homepage as the default route
  { path: '/consultar-inventario', component: ConsultarInventario },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
